//container defaults
var foodCont = Backbone.Model.extend({
	defaults: {
		name: "",
		brand: "",
		calories: "",
		servingSize: ""
	}

});